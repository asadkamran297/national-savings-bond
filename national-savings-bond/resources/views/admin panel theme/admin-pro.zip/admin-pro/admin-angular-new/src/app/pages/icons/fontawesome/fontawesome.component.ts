import { Component} from '@angular/core';
@Component({
	templateUrl: 'fontawesome.component.html',
	styleUrls: ['../icon.component.css'] 
})
export class fontawesomeComponent {
	
}