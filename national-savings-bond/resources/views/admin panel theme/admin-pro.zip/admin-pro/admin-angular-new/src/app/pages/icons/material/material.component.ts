import { Component} from '@angular/core';
@Component({
	templateUrl: 'material.component.html',
	styleUrls: ['../icon.component.css']  
})
export class MaterialComponent {
	
}